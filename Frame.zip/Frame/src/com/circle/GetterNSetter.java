package com.circle;

import java.nio.file.attribute.UserDefinedFileAttributeView;

public class GetterNSetter {
    String user = "";
    String password = "";
    String email = "";

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
