package com.circle;


import org.w3c.dom.Text;

import javax.swing.*;
import java.awt.event.ActionListener;




public class Main  {


    public static void main(String[] args) throws ClassNotFoundException, UnsupportedLookAndFeelException, InstantiationException, IllegalAccessException {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());


        // muss rausfinden wie ich nun die nullen und die zahl gegenseitig ersetze um
        // eine Zhal am ende zu haben die so aussehen kann 00000000001 und, dass der computer da
        // aufrechent und nicht die 0en überspringt so wie er es bis jetzt immer getan hat
        //

        CreateAccount acc = new CreateAccount();

        /*GetterNSetter a = new GetterNSetter();
        //a.setPassword("hello");
        System.out.println(a.getPassword());*/




        //GUI2 guii = new GUI2();
        //CreateAccount acc = new CreateAccount();
        /*SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Login log = new Login();
                log.setVisible(true);
            }
        });*/

    }
}
