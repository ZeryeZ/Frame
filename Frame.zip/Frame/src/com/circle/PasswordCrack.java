package com.circle;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class PasswordCrack extends JFrame {


    private static JFrame ckrack;
    private static JPanel panel;
    private static JToggleButton confirm;
    private static JToggleButton decline;
    private static JLabel text;
    private static JLabel text1;

    public PasswordCrack() {

        GetterNSetter b = new GetterNSetter();
        String password = b.getPassword();

    controller handler = new controller();


        ckrack = new JFrame();
        ckrack.setSize(300, 150);
        ckrack.setLocationRelativeTo(null);
        ckrack.setTitle("Passwort Hack Option");


        panel = new JPanel();
        panel.setLayout(null);

        text = new JLabel();
        text.setBounds(30,5,300,20);
        text.setText("You want to check if you Password is safe?");
        panel.add(text);

        text1 = new JLabel();
        text1.setBounds(30, 30, 300, 20);
        text1.setText("Then press Confirm !");
        panel.add(text1);


        confirm = new JToggleButton("Confirm");
        confirm.addActionListener(handler);
        confirm.setBounds(10,50,125,50);
        panel.add(confirm);


        decline = new JToggleButton("Decline");
        decline.addActionListener(handler);
        decline.setBounds(155, 50, 125, 50);
        panel.add(decline);

        ckrack.setDefaultCloseOperation(ckrack.EXIT_ON_CLOSE);
        ckrack.add(panel);
        ckrack.setVisible(true);
    }

    private class controller implements ActionListener{

        public void actionPerformed(ActionEvent event) {

            if (event.getSource() == confirm){
                while (true) {
                    GetterNSetter g = new GetterNSetter();
                    String computer = "";
                    int trys = 0;
                    long startTime = System.nanoTime();
                    long endTime = System.nanoTime();
                    long totalTime = endTime - startTime;
                    String password = g.getPassword();
                    System.out.println(password);

                    // Ich muss versuchen, es zu schaffen, das der Computer das Passwort erkennt
                    //und dann damit vergleichen kann um zu schauen ob er es geknackt hat oder nicht
                    // da es zuvor ging und nun nachdem ich aus dem nächsten fenster eine neue klasse gemacht habe
                    // funktioniert der vergleich nichtmehr
                    

                    while (true) {

                        computer = String.valueOf(trys);
                        System.out.println(computer +  " " + password);
                        if (computer.equals(password)) {
                            JOptionPane.showMessageDialog(null, "The computer cracked you password with: "
                                    + trys + " trys\n" + "The Computer needed: " + totalTime + "nanoseconds");
                            break;
                        }
                        else {
                            trys++;
                            System.out.println(computer + "\n" + password);
                            System.out.println("");
                        }
                    }
                }
            }
            else if (event.getSource() == decline){
                ckrack.dispose();
                System.exit(0);
            }
        }
    }
}
