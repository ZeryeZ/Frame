package com.circle;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame{
    private JButton confirmButton;
    private JTextField Password;
    private JTextField Login;
    private JButton Cancel;
    private JPanel rootPanel;

    public Login() {
        add(rootPanel);
        setTitle("Login");
        setSize(500,200);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(rootPanel, "is Pressed !1");
            }
        });
        Cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showConfirmDialog(rootPanel,"done");
            }
        });
    }

}
