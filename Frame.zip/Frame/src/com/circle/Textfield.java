package com.circle;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Textfield extends JFrame  {


        JTextField login;
        JTextField pass;

        public Textfield() throws InterruptedException {
            login = new JTextField();
            pass = new JTextField();
            pass.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent arg0) {
                    System.out.println("DO SOMETHING");
                }
            });
            add(login, BorderLayout.NORTH);
            add(pass, BorderLayout.SOUTH);
            pack();
            setVisible(true);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
}

