package com.circle;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tutorial extends JFrame implements ActionListener{


        JButton button1;
        JButton button2;

        JTextField text1;
        JTextField text2;

        JLabel label;
        JPanel panel;

        public Tutorial() {
            this.setTitle("");
            this.setSize(400, 200);
            panel = new JPanel();



            // Leeres JLabel-Objekt wird erzeugt
            label = new JLabel();

            //Drei Buttons werden erstellt
            button1 = new JButton("Confirm");
            button2 = new JButton("Cancel");
            button1.setLocation(200,100);
            button2.setLocation(300,200);



            text1 = new JTextField("Login");
            text2 = new JTextField("Password");

            //Buttons werden dem Listener zugeordnet
            button1.addActionListener(this);
            button2.addActionListener(this);
            //Anordung der Knöpfe und der Textfelder fehelen noch!!

            //Buttons werden dem JPanel hinzugefügt
            panel.add(text1);
            panel.add(text2);
            panel.add(button1);
            panel.add(button2);



            //JLabel wird dem Panel hinzugefügt
            panel.add(label);
            this.add(panel);
        }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Die Quelle wird mit getSource() abgefragt und mit den
        // Buttons abgeglichen. Wenn die Quelle des ActionEvents einer
        // der Buttons ist, wird der Text des JLabels entsprechend geändert
        if (e.getSource() == this.button1) {
            label.setText(("Button 1 wurde betätigt"));

        } else if (e.getSource() == this.button2) {
            label.setText("Button 2 wurde betätigt");
            dispose();

        }
    }
}
