package com.circle;

import javax.lang.model.type.TypeMirror;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateAccount extends JFrame {

    private static JFrame frame;
    private static JPanel panel;
    private static JLabel username;
    private static JLabel password;
    private static JLabel email;
    private static JTextField usernamefield;
    private static JPasswordField passwordfied;
    private static JTextField emailadress;
    private static JButton register;
    private static JLabel indicator;
    private static JLabel indicator2;

    public CreateAccount() {
        frame = new JFrame();
        panel = new JPanel();
        frame.setTitle("Register to Dreamworld");

        actions a = new actions();

        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        frame.setSize(350,230);
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);

        username = new JLabel("Username");
        username.setBounds(10,20,60,20);
        panel.add(username);

        usernamefield = new JTextField();
        usernamefield.setBounds(100,20,200,20);
        panel.add(usernamefield);

        password = new JLabel("Password*");
        password.setBounds(10,50,60,20);
        panel.add(password);

        passwordfied = new JPasswordField();
        passwordfied.setBounds(100,50,200,20);
        panel.add(passwordfied);

        email = new JLabel("Email");
        email.setBounds(10,80,60,20);
        panel.add(email);

        emailadress = new JTextField();
        emailadress.setBounds(100,80,200,20);
        panel.add(emailadress);

        register = new JButton("Register");
        register.setBounds(170,130,130,40);
        register.setBackground(Color.green);
        register.setBorder(null);
        register.addActionListener(a);
        panel.add(register);

        indicator = new JLabel("*Password only numbers");
        indicator.setBounds(10,130,200,20);
        panel.add(indicator);

        indicator2 = new JLabel("without 0 starting");
        indicator2.setBounds(10,150,100,20);
        panel.add(indicator2);

        frame.add(panel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }

    private class actions implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            String password = new String(passwordfied.getPassword());
            String user = usernamefield.getText();
            String email = emailadress.getText();
            GetterNSetter a = new GetterNSetter();
            a.setUser(user);
            a.setPassword(password);
            a.setEmail(email);
            System.out.println(a.getPassword());



            String pattern = "@";
            Pattern p = Pattern.compile(pattern);
            Matcher m = p.matcher(email);
            boolean fount = m.find();
            System.out.println(fount);
            String pattern2 = "\\.";
            Pattern q = Pattern.compile(pattern2);
            Matcher n = q.matcher(email);
            boolean dots = n.find();

            if (!user.equals("") && !password.equals("") && fount == true && !email.equals("") && password.matches("[0-9]+") && dots == true) {
                System.out.println("Register successful");
                JOptionPane.showMessageDialog(panel, "You have successful Registered");
                PasswordCrack o = new PasswordCrack();
            } else {
                System.out.println("Register incomplete!");
                JOptionPane.showMessageDialog(panel, "You Register is incomplete please watch out that you have a correct email and a correct Password");

            }

        }
    }

}
